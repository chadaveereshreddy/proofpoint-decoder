// Author: Manikanta Payasam & Veeresh Reddy Chada
// OpenSource


function genericOnClick(info, tab) 
{
	var iurl = info.linkUrl;
        var ppurl = iurl.search(/proofpoint.com/g) 
        if(ppurl!=-1)
	{

	var start = iurl.indexOf("l?u=") + 4
	var end = iurl.indexOf("&d=")
	var furl = iurl.substring(start, end)
	var url = furl.replace(/-3A/g, ":").replace(/_/g, "/").replace(/-7E/g, "~").replace(/-2560/g, "`").replace(/-21/g, "!").replace(/-40/g, "@").replace(/-23/g, "#")
	var url2 = url.replace(/-24/g, "$").replace(/-25/g, "%").replace(/-255E/g, "^").replace(/-26/g, "&").replace(/-2A/g, "*").replace(/-28/g, "(").replace(/-29/g, ")")
	var url3 = url2.replace(/-5F/g, "_").replace(/-2B/g, "+").replace(/-3D/g, "=").replace(/-257B/g, "{").replace(/257D/g, "}").replace(/-257C/g, "|")
	var url4 = url3.replace(/-5B/g, "[").replace(/-5D/g, "]").replace(/-255C/g, "\\").replace(/-26quot-3B/g, "\"").replace(/-3B/g, ";").replace(/-26-2339-3B/g, "'").replace(/-26lt-3B/g, "<")
	var url5 = url4.replace(/-26gt-3B/g, ">").replace(/-3F/g, "?").replace(/-2C/g, ",")
	var url6 = url5.replace(/-2D/g, "-")

 	alert("Final URL is: " + url6);
	
  	var dummy = document.createElement("input");

  	document.body.appendChild(dummy);

  	dummy.setAttribute("id", "dummy_id");

  	document.getElementById("dummy_id").value=url6;
  	
  	dummy.select();

  	document.execCommand("copy");

  	document.body.removeChild(dummy);
        }
        else
       {
	alert("Not a profpoint URL");	
	}
}

var title = "Decode PP URL";
var contexts = ["link"];
var id = chrome.contextMenus.create({"title": title, "contexts":contexts,
    "onclick": genericOnClick});
